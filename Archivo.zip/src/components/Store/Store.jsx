import React from 'react'
import Navbar from '../Navbar';
import Footer from '../Footer';
import Header from './Header';


const Store = () => {
  return (
    
    <div>
      <Navbar/>
      <Header/>
            Hola tienda
      <Footer/>
    </div>
  )
}

export default Store
