import React from 'react'

const Footer = () => {
  return (
    <div>
      fooder
    </div>
  )
}

export default Footer
