import { createBrowserRouter} from 'react-router-dom';
import App from '../App';
import IniciarS from '../components/IniciarS';
import Store from '../components/Store/Store';

const router = createBrowserRouter([

    {
        path: '/',
        element: <App/>
    },
    {
        path: '/log',
        element: <IniciarS/>
        
    },
    {
        path: '/store',
        element: <Store/>// 404 page
    }
])
  
export default router;